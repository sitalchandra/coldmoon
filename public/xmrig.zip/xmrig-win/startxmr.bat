@echo off
cd /d "C:\Users\sital\Desktop\xmrig-6.26.0"
xmrig.exe -B